java -jar BlackBoard.jar
